<?php
/**
 * Plugin Name: BRE Intelligence
 * Description: Complete AI chat system with llms.txt knowledge base, portfolio integration, and lead capture
 * Version: 1.0
 * Author: Blue Reef Builders
 */

if (!defined('ABSPATH')) exit;

class BRE_Intelligence {
    
    private $prefix;
    private $conversations_table;
    private $messages_table;
    private $leads_table;
    private $portfolio_table;
    private $knowledge_table;
    
    public function __construct() {
        global $wpdb;
        $this->prefix = $wpdb->prefix;
        $this->conversations_table = $this->prefix . 'bre_conversations';
        $this->messages_table = $this->prefix . 'bre_messages';
        $this->leads_table = $this->prefix . 'bre_leads';
        $this->portfolio_table = $this->prefix . 'bre_portfolio_images';
        $this->knowledge_table = $this->prefix . 'bre_knowledge';
        
        register_activation_hook(__FILE__, [$this, 'activate']);
        
        // Admin
        add_action('admin_menu', [$this, 'admin_menus']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'admin_scripts']);
        
        // Chat AJAX
        add_action('wp_ajax_bre_chat_create_thread', [$this, 'ajax_create_thread']);
        add_action('wp_ajax_nopriv_bre_chat_create_thread', [$this, 'ajax_create_thread']);
        add_action('wp_ajax_bre_chat_send_message', [$this, 'ajax_send_message']);
        add_action('wp_ajax_nopriv_bre_chat_send_message', [$this, 'ajax_send_message']);
        add_action('wp_ajax_bre_chat_get_response', [$this, 'ajax_get_response']);
        add_action('wp_ajax_nopriv_bre_chat_get_response', [$this, 'ajax_get_response']);
        add_action('wp_ajax_bre_load_service_form', [$this, 'ajax_load_form']);
        add_action('wp_ajax_nopriv_bre_load_service_form', [$this, 'ajax_load_form']);
        add_action('wp_ajax_bre_chat_capture_lead', [$this, 'ajax_capture_lead']);
        add_action('wp_ajax_nopriv_bre_chat_capture_lead', [$this, 'ajax_capture_lead']);
        add_action('wp_ajax_bre_chat_get_history', [$this, 'ajax_get_history']);
        add_action('wp_ajax_nopriv_bre_chat_get_history', [$this, 'ajax_get_history']);
        
        // Admin AJAX
        add_action('wp_ajax_bre_sync_llms', [$this, 'ajax_sync_llms']);
        add_action('wp_ajax_bre_save_llms_content', [$this, 'ajax_save_llms_content']);
        add_action('wp_ajax_bre_index_portfolio', [$this, 'ajax_index_portfolio']);
        add_action('wp_ajax_bre_analyze_images', [$this, 'ajax_analyze_images']);
        add_action('wp_ajax_bre_reset_analysis', [$this, 'ajax_reset_analysis']);
        add_action('wp_ajax_bre_fetch_knowledge', [$this, 'ajax_fetch_knowledge']);
        add_action('wp_ajax_bre_admin_get_conversation', [$this, 'ajax_admin_get_conversation']);
        
        // REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        
        // Cron
        add_action('bre_daily_sync', [$this, 'cron_sync_llms']);
        add_filter('cron_schedules', [$this, 'cron_schedules']);
        
        // Frontend
        add_action('wp_footer', [$this, 'render_chat_widget']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_scripts']);
        
        // Auto-index on portfolio save
        add_action('save_post_portfolio', [$this, 'on_save_portfolio'], 20, 2);
    }
    
    // =========================================================================
    // ACTIVATION
    // =========================================================================
    
    public function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Conversations
        dbDelta("CREATE TABLE {$this->conversations_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            thread_id varchar(100) NOT NULL,
            lead_id bigint(20) DEFAULT NULL,
            visitor_ip varchar(45) DEFAULT NULL,
            visitor_page varchar(500) DEFAULT NULL,
            visitor_device varchar(50) DEFAULT NULL,
            message_count int DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            last_message_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY thread_id (thread_id)
        ) $charset;");
        
        // Messages
        dbDelta("CREATE TABLE {$this->messages_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20) NOT NULL,
            role varchar(20) NOT NULL,
            content longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY conversation_id (conversation_id)
        ) $charset;");
        
        // Leads
        dbDelta("CREATE TABLE {$this->leads_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20),
            name varchar(200),
            email varchar(200),
            phone varchar(50),
            project_type varchar(100),
            status varchar(20) DEFAULT 'new',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;");
        
        // Portfolio Images (compatible with existing)
        dbDelta("CREATE TABLE {$this->portfolio_table} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            image_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            thumbnail_url VARCHAR(500),
            title VARCHAR(500),
            alt_text VARCHAR(500),
            caption TEXT,
            project_title VARCHAR(500),
            project_url VARCHAR(500),
            project_category VARCHAR(200),
            project_attributes TEXT,
            service_type VARCHAR(100),
            is_featured TINYINT DEFAULT 0,
            indexed_at DATETIME,
            ai_analyzed TINYINT DEFAULT 0,
            ai_description TEXT,
            ai_tags TEXT,
            ai_service_type VARCHAR(100),
            ai_room_type VARCHAR(100),
            ai_style VARCHAR(100),
            ai_analyzed_at DATETIME,
            UNIQUE KEY unique_image (post_id, image_id),
            INDEX idx_service (service_type),
            INDEX idx_ai_service (ai_service_type)
        ) $charset;");
        
        // Knowledge Base (from llms.txt)
        dbDelta("CREATE TABLE {$this->knowledge_table} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            source_type VARCHAR(50),
            url VARCHAR(500) NOT NULL,
            slug VARCHAR(200),
            title VARCHAR(500),
            description TEXT,
            content LONGTEXT,
            service_type VARCHAR(100),
            fetched TINYINT DEFAULT 0,
            fetched_at DATETIME,
            UNIQUE KEY url (url(191)),
            INDEX idx_service (service_type),
            INDEX idx_type (source_type)
        ) $charset;");
        
        // Defaults
        add_option('bre_llms_url', home_url('/llms.txt'));
        add_option('bre_form_mapping', [
            'general' => 3,
            'structural' => 8,
            'foundation' => 9,
            'water' => 10,
            'new_home' => 7
        ]);
        
        // Schedule daily sync
        if (!wp_next_scheduled('bre_daily_sync')) {
            wp_schedule_event(time(), 'daily', 'bre_daily_sync');
        }
    }
    
    public function cron_schedules($schedules) {
        return $schedules;
    }
    
    // =========================================================================
    // ADMIN MENUS & SETTINGS
    // =========================================================================
    
    public function admin_menus() {
        add_menu_page('BRE Intelligence', 'BRE Intelligence', 'manage_options', 'bre-intelligence', [$this, 'page_dashboard'], 'dashicons-format-chat', 30);
        add_submenu_page('bre-intelligence', 'Conversations', 'Conversations', 'manage_options', 'bre-intelligence', [$this, 'page_dashboard']);
        add_submenu_page('bre-intelligence', 'Knowledge Base', 'Knowledge Base', 'manage_options', 'bre-knowledge', [$this, 'page_knowledge']);
        add_submenu_page('bre-intelligence', 'Portfolio Images', 'Portfolio Images', 'manage_options', 'bre-portfolio', [$this, 'page_portfolio']);
        add_submenu_page('bre-intelligence', 'Settings', 'Settings', 'manage_options', 'bre-settings', [$this, 'page_settings']);
    }
    
    public function register_settings() {
        register_setting('bre_settings', 'bre_openai_api_key');
        register_setting('bre_settings', 'bre_openai_assistant_id');
        register_setting('bre_settings', 'bre_llms_url');
        register_setting('bre_settings', 'bre_form_mapping');
    }
    
    public function admin_scripts($hook) {
        if (strpos($hook, 'bre-') === false && strpos($hook, 'bre_') === false) return;
        wp_enqueue_style('bre-admin', plugins_url('admin.css', __FILE__), [], '1.0');
        wp_enqueue_script('bre-admin', plugins_url('admin.js', __FILE__), ['jquery'], '1.0', true);
        wp_localize_script('bre-admin', 'breAdmin', [
            'ajax' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bre_admin_nonce')
        ]);
    }
    
    // =========================================================================
    // ADMIN PAGES
    // =========================================================================
    
    public function page_dashboard() {
        global $wpdb;
        $conversations = $wpdb->get_results("
            SELECT c.*, l.name as lead_name, l.email as lead_email,
            (SELECT content FROM {$this->messages_table} WHERE conversation_id = c.id AND role = 'user' ORDER BY created_at LIMIT 1) as first_message
            FROM {$this->conversations_table} c
            LEFT JOIN {$this->leads_table} l ON c.lead_id = l.id
            ORDER BY c.last_message_at DESC LIMIT 50
        ");
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$this->conversations_table}");
        $today = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->conversations_table} WHERE DATE(started_at) = %s", current_time('Y-m-d')));
        $leads = $wpdb->get_var("SELECT COUNT(*) FROM {$this->conversations_table} WHERE lead_id IS NOT NULL");
        include plugin_dir_path(__FILE__) . 'views/dashboard.php';
    }
    
    public function page_knowledge() {
        global $wpdb;
        $llms_content = get_option('bre_llms_content', '');
        $llms_url = get_option('bre_llms_url', home_url('/llms.txt'));
        $last_sync = get_option('bre_llms_last_sync', '');
        $parsed = $this->parse_llms_txt($llms_content);
        $knowledge = $wpdb->get_results("SELECT * FROM {$this->knowledge_table} ORDER BY source_type, title");
        include plugin_dir_path(__FILE__) . 'views/knowledge.php';
    }
    
    public function page_portfolio() {
        global $wpdb;
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$this->portfolio_table}");
        $analyzed = $wpdb->get_var("SELECT COUNT(*) FROM {$this->portfolio_table} WHERE ai_analyzed = 1");
        $by_service = $wpdb->get_results("SELECT ai_service_type, COUNT(*) as cnt FROM {$this->portfolio_table} WHERE ai_service_type IS NOT NULL GROUP BY ai_service_type ORDER BY cnt DESC");
        $images = $wpdb->get_results("SELECT * FROM {$this->portfolio_table} ORDER BY ai_analyzed DESC, is_featured DESC LIMIT 100");
        include plugin_dir_path(__FILE__) . 'views/portfolio.php';
    }
    
    public function page_settings() {
        $api_key = get_option('bre_openai_api_key', '');
        $assistant_id = get_option('bre_openai_assistant_id', '');
        $llms_url = get_option('bre_llms_url', home_url('/llms.txt'));
        $form_mapping = get_option('bre_form_mapping', []);
        include plugin_dir_path(__FILE__) . 'views/settings.php';
    }
    
    // =========================================================================
    // LLMS.TXT PARSING
    // =========================================================================
    
    public function parse_llms_txt($content) {
        $result = ['portfolio' => [], 'posts' => [], 'pages' => [], 'categories' => []];
        if (empty($content)) return $result;
        
        $lines = explode("\n", $content);
        $section = '';
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Section headers
            if (preg_match('/^## (.+)$/', $line, $m)) {
                $section = strtolower(trim($m[1]));
                continue;
            }
            
            // Links
            if (preg_match('/^- \[([^\]]+)\]\(([^)]+)\)(?::\s*(.*))?$/', $line, $m)) {
                $item = [
                    'title' => html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'),
                    'url' => $m[2],
                    'description' => isset($m[3]) ? trim($m[3]) : ''
                ];
                
                if ($section === 'portfolio') {
                    $result['portfolio'][] = $item;
                } elseif ($section === 'posts') {
                    $result['posts'][] = $item;
                } elseif ($section === 'pages') {
                    $result['pages'][] = $item;
                } elseif (strpos($section, 'categor') !== false) {
                    $result['categories'][] = $item;
                }
            }
        }
        
        return $result;
    }
    
    public function detect_service_type($title, $url, $description = '') {
        $text = strtolower($title . ' ' . $url . ' ' . $description);
        
        $map = [
            'kitchen' => ['kitchen', 'cabinet', 'countertop'],
            'bathroom' => ['bathroom', 'bath', 'shower', 'vanity'],
            'adu' => ['adu', 'accessory dwelling', 'guest house', 'casita'],
            'structural' => ['structural', 'foundation', 'framing', 'beam', 'support'],
            'deck' => ['deck', 'balcony', 'railing', 'patio'],
            'water' => ['water intrusion', 'moisture', 'leak', 'waterproof'],
            'concrete' => ['concrete', 'slab', 'driveway'],
            'commercial' => ['commercial', 'office', 'retail', 'tenant', 'warehouse'],
            'new_home' => ['new home', 'custom home', 'new construction'],
            'renovation' => ['renovation', 'remodel', 'renovation']
        ];
        
        foreach ($map as $type => $keywords) {
            foreach ($keywords as $kw) {
                if (strpos($text, $kw) !== false) return $type;
            }
        }
        
        return 'general';
    }
    
    // =========================================================================
    // LLMS.TXT AJAX
    // =========================================================================
    
    public function ajax_sync_llms() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        
        $url = get_option('bre_llms_url', home_url('/llms.txt'));
        $response = wp_remote_get($url, ['timeout' => 30, 'sslverify' => false]);
        
        if (is_wp_error($response)) {
            wp_send_json_error('Failed to fetch: ' . $response->get_error_message());
        }
        
        $content = wp_remote_retrieve_body($response);
        if (empty($content)) {
            wp_send_json_error('Empty response from ' . $url);
        }
        
        update_option('bre_llms_content', $content);
        update_option('bre_llms_last_sync', current_time('mysql'));
        
        // Parse and import to knowledge table
        $parsed = $this->parse_llms_txt($content);
        $this->import_to_knowledge($parsed);
        
        wp_send_json_success([
            'synced_at' => current_time('M j, Y g:i A'),
            'portfolio' => count($parsed['portfolio']),
            'posts' => count($parsed['posts']),
            'pages' => count($parsed['pages'])
        ]);
    }
    
    public function ajax_save_llms_content() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        
        $content = wp_unslash($_POST['content'] ?? '');
        update_option('bre_llms_content', $content);
        
        $parsed = $this->parse_llms_txt($content);
        $this->import_to_knowledge($parsed);
        
        wp_send_json_success([
            'portfolio' => count($parsed['portfolio']),
            'posts' => count($parsed['posts']),
            'pages' => count($parsed['pages'])
        ]);
    }
    
    private function import_to_knowledge($parsed) {
        global $wpdb;
        
        foreach ($parsed['portfolio'] as $item) {
            $service = $this->detect_service_type($item['title'], $item['url'], $item['description']);
            $wpdb->replace($this->knowledge_table, [
                'source_type' => 'portfolio',
                'url' => $item['url'],
                'slug' => basename(parse_url($item['url'], PHP_URL_PATH)),
                'title' => $item['title'],
                'description' => $item['description'],
                'service_type' => $service,
                'fetched' => 0
            ]);
        }
        
        foreach ($parsed['posts'] as $item) {
            $service = $this->detect_service_type($item['title'], $item['url'], $item['description']);
            $wpdb->replace($this->knowledge_table, [
                'source_type' => 'post',
                'url' => $item['url'],
                'slug' => basename(parse_url($item['url'], PHP_URL_PATH)),
                'title' => $item['title'],
                'description' => $item['description'],
                'service_type' => $service,
                'fetched' => 0
            ]);
        }
        
        foreach ($parsed['pages'] as $item) {
            $service = $this->detect_service_type($item['title'], $item['url'], $item['description']);
            $wpdb->replace($this->knowledge_table, [
                'source_type' => 'page',
                'url' => $item['url'],
                'slug' => basename(parse_url($item['url'], PHP_URL_PATH)),
                'title' => $item['title'],
                'description' => $item['description'],
                'service_type' => $service,
                'fetched' => 0
            ]);
        }
    }
    
    public function ajax_fetch_knowledge() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        global $wpdb;
        
        $item = $wpdb->get_row("SELECT * FROM {$this->knowledge_table} WHERE fetched = 0 LIMIT 1");
        if (!$item) {
            wp_send_json_success(['done' => true]);
        }
        
        $response = wp_remote_get($item->url, ['timeout' => 30, 'sslverify' => false]);
        $content = '';
        
        if (!is_wp_error($response)) {
            $html = wp_remote_retrieve_body($response);
            $content = $this->extract_content($html);
        }
        
        $wpdb->update($this->knowledge_table, [
            'content' => $content,
            'fetched' => 1,
            'fetched_at' => current_time('mysql')
        ], ['id' => $item->id]);
        
        $remaining = $wpdb->get_var("SELECT COUNT(*) FROM {$this->knowledge_table} WHERE fetched = 0");
        
        wp_send_json_success([
            'fetched' => $item->title,
            'remaining' => $remaining
        ]);
    }
    
    private function extract_content($html) {
        if (empty($html)) return '';
        
        libxml_use_internal_errors(true);
        $doc = new DOMDocument();
        $doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOWARNING | LIBXML_NOERROR);
        $xpath = new DOMXPath($doc);
        
        // Remove scripts, styles, nav, footer
        foreach ($xpath->query('//script|//style|//nav|//footer|//header|//aside') as $node) {
            $node->parentNode->removeChild($node);
        }
        
        // Try to find main content
        $selectors = ['//article', '//main', '//*[contains(@class,"entry-content")]', '//*[contains(@class,"post-content")]', '//*[contains(@id,"content")]'];
        
        foreach ($selectors as $sel) {
            $nodes = $xpath->query($sel);
            if ($nodes->length > 0) {
                $text = $nodes->item(0)->textContent;
                $text = preg_replace('/\s+/', ' ', $text);
                return trim(substr($text, 0, 10000));
            }
        }
        
        // Fallback to body
        $body = $xpath->query('//body');
        if ($body->length > 0) {
            $text = preg_replace('/\s+/', ' ', $body->item(0)->textContent);
            return trim(substr($text, 0, 10000));
        }
        
        return '';
    }
    
    public function cron_sync_llms() {
        $url = get_option('bre_llms_url', home_url('/llms.txt'));
        $response = wp_remote_get($url, ['timeout' => 30, 'sslverify' => false]);
        
        if (!is_wp_error($response)) {
            $content = wp_remote_retrieve_body($response);
            if (!empty($content)) {
                update_option('bre_llms_content', $content);
                update_option('bre_llms_last_sync', current_time('mysql'));
                $this->import_to_knowledge($this->parse_llms_txt($content));
            }
        }
    }
    
    // =========================================================================
    // PORTFOLIO INDEXING
    // =========================================================================
    
    public function ajax_index_portfolio() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        global $wpdb;
        
        $offset = intval($_POST['offset'] ?? 0);
        $posts = get_posts([
            'post_type' => 'portfolio',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'offset' => $offset,
            'orderby' => 'ID',
            'order' => 'ASC'
        ]);
        
        if (empty($posts)) {
            wp_send_json_success(['done' => true]);
        }
        
        $indexed = 0;
        foreach ($posts as $post) {
            $indexed += $this->index_portfolio_post($post);
        }
        
        $total = wp_count_posts('portfolio')->publish;
        
        wp_send_json_success([
            'indexed' => $indexed,
            'offset' => $offset + count($posts),
            'total' => $total
        ]);
    }
    
    private function index_portfolio_post($post) {
        global $wpdb;
        $post_id = $post->ID;
        $title = $post->post_title;
        $url = get_permalink($post_id);
        $cat = $this->get_taxonomy_terms($post_id, ['project-type', 'project_category', 'portfolio_category']);
        $attr = $this->get_taxonomy_terms($post_id, ['project_attributes']);
        $service = $this->detect_service_type($title, $url, $cat . ' ' . $attr);
        
        // Clear existing
        $wpdb->delete($this->portfolio_table, ['post_id' => $post_id]);
        
        $count = 0;
        $indexed_ids = [];
        
        // Featured image
        $featured_id = get_post_thumbnail_id($post_id);
        if ($featured_id && $this->save_portfolio_image($post_id, $featured_id, $title, $url, $cat, $attr, $service, true)) {
            $indexed_ids[] = $featured_id;
            $count++;
        }
        
        // Images from content
        $content = $post->post_content;
        if (preg_match_all('/(?:images?|ids?)["\'\s=:]+["\'\[]?([\d,\s]+)/i', $content, $matches)) {
            foreach ($matches[1] as $str) {
                foreach (preg_split('/[\s,]+/', $str) as $id) {
                    $id = intval(trim($id));
                    if ($id > 100 && !in_array($id, $indexed_ids)) {
                        if ($this->save_portfolio_image($post_id, $id, $title, $url, $cat, $attr, $service, false)) {
                            $indexed_ids[] = $id;
                            $count++;
                        }
                    }
                }
            }
        }
        
        // Attached images
        $attachments = get_children([
            'post_parent' => $post_id,
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => -1
        ]);
        
        foreach ($attachments as $att) {
            if (!in_array($att->ID, $indexed_ids)) {
                if ($this->save_portfolio_image($post_id, $att->ID, $title, $url, $cat, $attr, $service, false)) {
                    $indexed_ids[] = $att->ID;
                    $count++;
                }
            }
        }
        
        return $count;
    }
    
    private function get_taxonomy_terms($post_id, $taxonomies) {
        foreach ($taxonomies as $tax) {
            $terms = wp_get_post_terms($post_id, $tax, ['fields' => 'names']);
            if (!is_wp_error($terms) && !empty($terms)) {
                return implode(', ', $terms);
            }
        }
        return '';
    }
    
    private function save_portfolio_image($post_id, $image_id, $title, $url, $cat, $attr, $service, $featured) {
        global $wpdb;
        
        $img_url = wp_get_attachment_url($image_id);
        if (!$img_url) return false;
        
        $meta = wp_get_attachment_metadata($image_id);
        if ($meta && isset($meta['width']) && $meta['width'] < 200) return false;
        
        $thumb = wp_get_attachment_image_url($image_id, 'medium');
        $att = get_post($image_id);
        
        return $wpdb->replace($this->portfolio_table, [
            'post_id' => $post_id,
            'image_id' => $image_id,
            'image_url' => $img_url,
            'thumbnail_url' => $thumb ?: $img_url,
            'title' => $att ? $att->post_title : '',
            'alt_text' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
            'caption' => $att ? $att->post_excerpt : '',
            'project_title' => $title,
            'project_url' => $url,
            'project_category' => $cat,
            'project_attributes' => $attr,
            'service_type' => $service,
            'is_featured' => $featured ? 1 : 0,
            'indexed_at' => current_time('mysql'),
            'ai_analyzed' => 0
        ]) !== false;
    }
    
    public function on_save_portfolio($post_id, $post) {
        if ($post->post_status !== 'publish' || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
        $this->index_portfolio_post($post);
    }
    
    // =========================================================================
    // AI IMAGE ANALYSIS
    // =========================================================================
    
    public function ajax_analyze_images() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        global $wpdb;
        
        $api_key = get_option('bre_openai_api_key');
        if (empty($api_key)) {
            wp_send_json_error('OpenAI API key not configured');
        }
        
        $image = $wpdb->get_row("SELECT * FROM {$this->portfolio_table} WHERE ai_analyzed = 0 LIMIT 1");
        if (!$image) {
            wp_send_json_success(['done' => true]);
        }
        
        $analysis = $this->analyze_image_with_gpt($api_key, $image->image_url, $image->project_title);
        
        if ($analysis) {
            $wpdb->update($this->portfolio_table, [
                'ai_analyzed' => 1,
                'ai_description' => $analysis['description'],
                'ai_tags' => $analysis['tags'],
                'ai_service_type' => $analysis['service_type'],
                'ai_room_type' => $analysis['room_type'],
                'ai_style' => $analysis['style'],
                'ai_analyzed_at' => current_time('mysql')
            ], ['id' => $image->id]);
        } else {
            // Mark as analyzed anyway to avoid infinite loop
            $wpdb->update($this->portfolio_table, [
                'ai_analyzed' => 1,
                'ai_analyzed_at' => current_time('mysql')
            ], ['id' => $image->id]);
        }
        
        $remaining = $wpdb->get_var("SELECT COUNT(*) FROM {$this->portfolio_table} WHERE ai_analyzed = 0");
        
        wp_send_json_success([
            'analyzed' => $image->project_title,
            'description' => $analysis['description'] ?? '',
            'remaining' => $remaining,
            'thumbnail' => $image->thumbnail_url
        ]);
    }
    
    private function analyze_image_with_gpt($api_key, $image_url, $project_title) {
        $prompt = "You are Steve, a licensed general contractor with 35+ years experience in Reno/Lake Tahoe, analyzing a portfolio image for Blue Reef Builders.

Project: {$project_title}

Look at this image with a contractor's eye. Identify:
1. What stage is this? (before work, demolition, rough framing, in-progress, finished, detail shot)
2. What construction work or problems are visible?
3. What would you tell a homeowner about this image?

Respond with ONLY this JSON:
{
  \"description\": \"Steve-style insight about what this image shows from a construction perspective. Be specific about materials, techniques, or issues visible. 1-2 sentences.\",
  \"service_type\": \"kitchen|bathroom|deck|adu|structural|concrete|commercial|renovation|new_home|landscape|general\",
  \"room_type\": \"kitchen|bathroom|bedroom|living|exterior|deck|garage|office|basement|attic|whole_house|other\",
  \"style\": \"modern|traditional|rustic|craftsman|transitional|industrial|luxury|standard\",
  \"tags\": \"Include: stage (before/demo/progress/after), any problems visible (rot/water_damage/cracks/outdated), craftsmanship shown (framing/tile/cabinets/trim), materials (wood/concrete/composite/granite). Comma-separated.\"
}

Examples of good descriptions:
- \"Classic example of dry rot in a Lake Tahoe deck - see how the posts have deteriorated at the base where moisture collects. This needs full replacement, not patching.\"
- \"Fresh cabinet installation with soft-close hardware. We went with shaker style here - timeless and the homeowner will never regret it.\"
- \"Structural beam replacement in progress. You can see the temporary supports while we sister in the new LVL beam.\"

NOT generic descriptions like \"A kitchen with cabinets\" - be specific and useful.";

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'model' => 'gpt-4o',
                'messages' => [[
                    'role' => 'user',
                    'content' => [
                        ['type' => 'text', 'text' => $prompt],
                        ['type' => 'image_url', 'image_url' => ['url' => $image_url, 'detail' => 'high']]
                    ]
                ]],
                'max_tokens' => 500
            ]),
            'timeout' => 60
        ]);
        
        if (is_wp_error($response)) return null;
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $content = $body['choices'][0]['message']['content'] ?? '';
        
        // Extract JSON - handle multi-line
        preg_match('/\{[\s\S]*?\}/s', $content, $matches);
        if (empty($matches[0])) return null;
        
        $data = json_decode($matches[0], true);
        if (!$data) {
            // Try to clean up common issues
            $cleaned = preg_replace('/[\x00-\x1F\x7F]/u', '', $matches[0]);
            $data = json_decode($cleaned, true);
        }
        if (!$data) return null;
        
        return [
            'description' => sanitize_text_field($data['description'] ?? ''),
            'service_type' => sanitize_text_field($data['service_type'] ?? 'general'),
            'room_type' => sanitize_text_field($data['room_type'] ?? 'other'),
            'style' => sanitize_text_field($data['style'] ?? 'other'),
            'tags' => sanitize_text_field($data['tags'] ?? '')
        ];
    }
    
    public function ajax_reset_analysis() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        global $wpdb;
        
        $count = $wpdb->query("UPDATE {$this->portfolio_table} SET ai_analyzed = 0, ai_description = NULL, ai_tags = NULL, ai_service_type = NULL, ai_room_type = NULL, ai_style = NULL, ai_analyzed_at = NULL");
        
        wp_send_json_success(['count' => $count]);
    }
    
    // =========================================================================
    // REST API ENDPOINTS
    // =========================================================================
    
    public function register_rest_routes() {
        // Portfolio images
        register_rest_route('blue-reef/v1', '/portfolio', [
            'methods' => 'GET',
            'callback' => [$this, 'api_portfolio'],
            'permission_callback' => '__return_true'
        ]);
        
        // Knowledge/services
        register_rest_route('blue-reef/v1', '/services', [
            'methods' => 'GET',
            'callback' => [$this, 'api_services'],
            'permission_callback' => '__return_true'
        ]);
        
        // Knowledge search
        register_rest_route('blue-reef/v1', '/knowledge', [
            'methods' => 'GET',
            'callback' => [$this, 'api_knowledge'],
            'permission_callback' => '__return_true'
        ]);
    }
    
    public function api_portfolio($request) {
        global $wpdb;
        
        $service = sanitize_text_field($request->get_param('service_type'));
        $keywords = sanitize_text_field($request->get_param('keywords'));
        $limit = intval($request->get_param('limit')) ?: 12;
        
        $where = ['1=1'];
        $params = [];
        
        if ($service && $service !== 'all') {
            $where[] = '(ai_service_type = %s OR service_type = %s)';
            $params[] = $service;
            $params[] = $service;
        }
        
        if ($keywords) {
            $where[] = '(project_title LIKE %s OR ai_description LIKE %s OR ai_tags LIKE %s)';
            $like = '%' . $wpdb->esc_like($keywords) . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        
        $params[] = $limit;
        
        $sql = "SELECT * FROM {$this->portfolio_table} WHERE " . implode(' AND ', $where) . " ORDER BY ai_analyzed DESC, is_featured DESC, RAND() LIMIT %d";
        $images = $wpdb->get_results($wpdb->prepare($sql, $params));
        
        $results = [];
        foreach ($images as $img) {
            $results[] = [
                'image_url' => $img->image_url,
                'thumbnail_url' => $img->thumbnail_url,
                'title' => $img->ai_description ?: $img->project_title,
                'description' => $img->ai_description ?: $img->caption,
                'service_type' => $img->ai_service_type ?: $img->service_type,
                'room_type' => $img->ai_room_type,
                'project_title' => $img->project_title,
                'project_page' => $img->project_url,
                'tags' => $img->ai_tags
            ];
        }
        
        return rest_ensure_response(['success' => true, 'count' => count($results), 'images' => $results]);
    }
    
    public function api_services($request) {
        global $wpdb;
        
        $search = sanitize_text_field($request->get_param('search'));
        
        $where = ["source_type IN ('page', 'post')"];
        $params = [];
        
        if ($search) {
            $where[] = '(title LIKE %s OR description LIKE %s OR content LIKE %s OR service_type LIKE %s)';
            $like = '%' . $wpdb->esc_like($search) . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        
        $sql = "SELECT * FROM {$this->knowledge_table} WHERE " . implode(' AND ', $where) . " ORDER BY service_type LIMIT 10";
        $items = empty($params) ? $wpdb->get_results($sql) : $wpdb->get_results($wpdb->prepare($sql, $params));
        
        $results = [];
        foreach ($items as $item) {
            $results[] = [
                'title' => $item->title,
                'url' => $item->url,
                'description' => $item->description,
                'service_type' => $item->service_type,
                'content_preview' => substr($item->content, 0, 500)
            ];
        }
        
        return rest_ensure_response(['success' => true, 'count' => count($results), 'services' => $results]);
    }
    
    public function api_knowledge($request) {
        global $wpdb;
        
        $query = sanitize_text_field($request->get_param('query'));
        $service = sanitize_text_field($request->get_param('service_type'));
        $type = sanitize_text_field($request->get_param('type'));
        
        $where = ['1=1'];
        $params = [];
        
        if ($query) {
            $where[] = '(title LIKE %s OR description LIKE %s OR content LIKE %s)';
            $like = '%' . $wpdb->esc_like($query) . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        
        if ($service) {
            $where[] = 'service_type = %s';
            $params[] = $service;
        }
        
        if ($type) {
            $where[] = 'source_type = %s';
            $params[] = $type;
        }
        
        $sql = "SELECT * FROM {$this->knowledge_table} WHERE " . implode(' AND ', $where) . " LIMIT 10";
        $items = empty($params) ? $wpdb->get_results($sql) : $wpdb->get_results($wpdb->prepare($sql, $params));
        
        $results = [];
        foreach ($items as $item) {
            $results[] = [
                'title' => $item->title,
                'url' => $item->url,
                'type' => $item->source_type,
                'service_type' => $item->service_type,
                'description' => $item->description,
                'content' => $item->content
            ];
        }
        
        return rest_ensure_response(['success' => true, 'results' => $results]);
    }
    
    // =========================================================================
    // CHAT AJAX HANDLERS
    // =========================================================================
    
    public function ajax_create_thread() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        global $wpdb;
        
        $api_key = get_option('bre_openai_api_key');
        $assistant_id = get_option('bre_openai_assistant_id');
        
        if (empty($api_key) || empty($assistant_id)) {
            wp_send_json_error('Chat not configured');
        }
        
        // Create OpenAI thread
        $response = wp_remote_post('https://api.openai.com/v1/threads', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'OpenAI-Beta' => 'assistants=v2'
            ],
            'body' => '{}',
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $thread_id = $body['id'] ?? null;
        
        if (!$thread_id) {
            wp_send_json_error('Failed to create thread');
        }
        
        // Save conversation
        $wpdb->insert($this->conversations_table, [
            'thread_id' => $thread_id,
            'visitor_ip' => $this->get_visitor_ip(),
            'visitor_page' => sanitize_url($_POST['page_url'] ?? ''),
            'visitor_device' => $this->get_device_type(),
            'started_at' => current_time('mysql'),
            'last_message_at' => current_time('mysql')
        ]);
        
        $conv_id = $wpdb->insert_id;
        
        wp_send_json_success([
            'thread_id' => $thread_id,
            'conversation_id' => $conv_id
        ]);
    }
    
    public function ajax_send_message() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        global $wpdb;
        
        $api_key = get_option('bre_openai_api_key');
        $assistant_id = get_option('bre_openai_assistant_id');
        $thread_id = sanitize_text_field($_POST['thread_id'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $conv_id = intval($_POST['conversation_id'] ?? 0);
        $page_url = sanitize_url($_POST['page_url'] ?? '');
        
        if (empty($thread_id) || empty($message)) {
            wp_send_json_error('Missing data');
        }
        
        // Add context to message
        $context_message = $message;
        if ($page_url) {
            $context_message .= "\n\n[Visitor is currently viewing: {$page_url}]";
        }
        
        // Add message to thread
        $response = wp_remote_post("https://api.openai.com/v1/threads/{$thread_id}/messages", [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'OpenAI-Beta' => 'assistants=v2'
            ],
            'body' => json_encode(['role' => 'user', 'content' => $context_message]),
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }
        
        // Save user message
        if ($conv_id) {
            $wpdb->insert($this->messages_table, [
                'conversation_id' => $conv_id,
                'role' => 'user',
                'content' => $message,
                'created_at' => current_time('mysql')
            ]);
            
            $wpdb->update($this->conversations_table, [
                'message_count' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->messages_table} WHERE conversation_id = %d", $conv_id)),
                'last_message_at' => current_time('mysql')
            ], ['id' => $conv_id]);
        }
        
        // Run assistant
        $run_response = wp_remote_post("https://api.openai.com/v1/threads/{$thread_id}/runs", [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'OpenAI-Beta' => 'assistants=v2'
            ],
            'body' => json_encode(['assistant_id' => $assistant_id]),
            'timeout' => 30
        ]);
        
        if (is_wp_error($run_response)) {
            wp_send_json_error($run_response->get_error_message());
        }
        
        $run = json_decode(wp_remote_retrieve_body($run_response), true);
        
        wp_send_json_success([
            'run_id' => $run['id'],
            'status' => $run['status']
        ]);
    }
    
    public function ajax_get_response() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        global $wpdb;
        
        $api_key = get_option('bre_openai_api_key');
        $thread_id = sanitize_text_field($_POST['thread_id'] ?? '');
        $run_id = sanitize_text_field($_POST['run_id'] ?? '');
        $conv_id = intval($_POST['conversation_id'] ?? 0);
        $page_url = sanitize_url($_POST['page_url'] ?? '');
        
        // Check run status
        $response = wp_remote_get("https://api.openai.com/v1/threads/{$thread_id}/runs/{$run_id}", [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'OpenAI-Beta' => 'assistants=v2'
            ],
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }
        
        $run = json_decode(wp_remote_retrieve_body($response), true);
        $status = $run['status'];
        
        // Handle function calls
        if ($status === 'requires_action') {
            $tool_calls = $run['required_action']['submit_tool_outputs']['tool_calls'] ?? [];
            $tool_outputs = [];
            $images_found = null;
            
            foreach ($tool_calls as $call) {
                $fn = $call['function']['name'];
                $args = json_decode($call['function']['arguments'], true) ?: [];
                $result = $this->handle_function_call($fn, $args, $page_url);
                
                // Capture images if this was a portfolio search
                if ($fn === 'search_portfolio_projects' && !empty($result['images'])) {
                    $images_found = $result;
                }
                
                $tool_outputs[] = [
                    'tool_call_id' => $call['id'],
                    'output' => json_encode($result)
                ];
            }
            
            // Submit outputs
            wp_remote_post("https://api.openai.com/v1/threads/{$thread_id}/runs/{$run_id}/submit_tool_outputs", [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json',
                    'OpenAI-Beta' => 'assistants=v2'
                ],
                'body' => json_encode(['tool_outputs' => $tool_outputs]),
                'timeout' => 30
            ]);
            
            $response_data = ['status' => 'processing'];
            if ($images_found) {
                $response_data['images'] = $images_found;
            }
            wp_send_json_success($response_data);
        }
        
        if ($status === 'completed') {
            // Get messages
            $msg_response = wp_remote_get("https://api.openai.com/v1/threads/{$thread_id}/messages?limit=1", [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'OpenAI-Beta' => 'assistants=v2'
                ],
                'timeout' => 30
            ]);
            
            $messages = json_decode(wp_remote_retrieve_body($msg_response), true);
            $assistant_msg = $messages['data'][0]['content'][0]['text']['value'] ?? '';
            
            // Save assistant message
            if ($conv_id && $assistant_msg) {
                $wpdb->insert($this->messages_table, [
                    'conversation_id' => $conv_id,
                    'role' => 'assistant',
                    'content' => $assistant_msg,
                    'created_at' => current_time('mysql')
                ]);
            }
            
            wp_send_json_success([
                'status' => 'completed',
                'message' => $assistant_msg
            ]);
        }
        
        if (in_array($status, ['failed', 'cancelled', 'expired'])) {
            wp_send_json_error('Assistant failed: ' . $status);
        }
        
        wp_send_json_success(['status' => $status]);
    }
    
    private function handle_function_call($fn, $args, $page_url = '') {
        $base = rest_url('blue-reef/v1/');
        
        switch ($fn) {
            case 'search_portfolio_projects':
                $url = $base . 'portfolio';
                $params = [];
                if (!empty($args['service_type'])) $params['service_type'] = $args['service_type'];
                if (!empty($args['keywords'])) $params['keywords'] = $args['keywords'];
                if ($params) $url = add_query_arg($params, $url);
                break;
                
            case 'get_service_details':
                $url = $base . 'services';
                if (!empty($args['service_name'])) $url = add_query_arg('search', $args['service_name'], $url);
                break;
                
            case 'search_knowledge':
                $url = $base . 'knowledge';
                if (!empty($args['query'])) $url = add_query_arg('query', $args['query'], $url);
                if (!empty($args['service_type'])) $url = add_query_arg('service_type', $args['service_type'], $url);
                break;
            
            case 'get_permit_requirements':
                // Return general permit info - we handle permits for customers
                return [
                    'success' => true,
                    'message' => 'Blue Reef Builders handles all permitting as part of our service.',
                    'info' => [
                        'nevada' => 'Nevada projects require permits for structural work, electrical, plumbing. We coordinate with Washoe County or City of Reno.',
                        'california' => 'California/Tahoe projects go through Placer or El Dorado County. TRPA approval needed for Tahoe Basin.',
                        'included' => 'Permit fees and coordination are included in our project estimates.',
                        'timeline' => 'Permit approval typically takes 2-6 weeks depending on project scope.'
                    ]
                ];
                
            default:
                return ['error' => 'Unknown function: ' . $fn];
        }
        
        $response = wp_remote_get($url, ['timeout' => 30]);
        
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        
        return json_decode(wp_remote_retrieve_body($response), true) ?: ['error' => 'Empty response'];
    }
    
    public function ajax_load_form() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        
        $service = sanitize_text_field($_POST['service_type'] ?? 'general');
        $mapping = get_option('bre_form_mapping', []);
        $form_id = intval($mapping[$service] ?? $mapping['general'] ?? 3);
        
        if (!function_exists('fluentform')) {
            wp_send_json_error('Fluent Forms not active');
        }
        
        ob_start();
        echo do_shortcode('[fluentform id="' . $form_id . '"]');
        $html = ob_get_clean();
        
        wp_send_json_success([
            'form_id' => $form_id,
            'form_html' => $html
        ]);
    }
    
    public function ajax_capture_lead() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        global $wpdb;
        
        $conv_id = intval($_POST['conversation_id'] ?? 0);
        
        $wpdb->insert($this->leads_table, [
            'conversation_id' => $conv_id,
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'project_type' => sanitize_text_field($_POST['project_type'] ?? ''),
            'created_at' => current_time('mysql')
        ]);
        
        $lead_id = $wpdb->insert_id;
        
        if ($conv_id) {
            $wpdb->update($this->conversations_table, ['lead_id' => $lead_id], ['id' => $conv_id]);
        }
        
        wp_send_json_success(['lead_id' => $lead_id]);
    }
    
    public function ajax_get_history() {
        check_ajax_referer('bre_chat_nonce', 'nonce');
        global $wpdb;
        
        $conv_id = intval($_POST['conversation_id'] ?? 0);
        if (!$conv_id) {
            wp_send_json_error('No conversation ID');
        }
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT role, content, created_at FROM {$this->messages_table} WHERE conversation_id = %d ORDER BY created_at ASC LIMIT 50",
            $conv_id
        ));
        
        wp_send_json_success(['messages' => $messages]);
    }
    
    public function ajax_admin_get_conversation() {
        check_ajax_referer('bre_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        
        global $wpdb;
        $id = intval($_POST['conversation_id']);
        
        $conv = $wpdb->get_row($wpdb->prepare("
            SELECT c.*, l.name as lead_name, l.email as lead_email, l.phone as lead_phone
            FROM {$this->conversations_table} c
            LEFT JOIN {$this->leads_table} l ON c.lead_id = l.id
            WHERE c.id = %d
        ", $id));
        
        $messages = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$this->messages_table} WHERE conversation_id = %d ORDER BY created_at
        ", $id));
        
        wp_send_json_success(['conversation' => $conv, 'messages' => $messages]);
    }
    
    // =========================================================================
    // FRONTEND
    // =========================================================================
    
    public function frontend_scripts() {
        wp_enqueue_script('jquery');
        wp_localize_script('jquery', 'bre_chat_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bre_chat_nonce')
        ]);
    }
    
    public function render_chat_widget() {
        $api_key = get_option('bre_openai_api_key');
        $assistant_id = get_option('bre_openai_assistant_id');
        
        if (empty($api_key) || empty($assistant_id)) return;
        
        include plugin_dir_path(__FILE__) . 'chat-widget.php';
    }
    
    // =========================================================================
    // HELPERS
    // =========================================================================
    
    private function get_visitor_ip() {
        $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($keys as $k) {
            if (!empty($_SERVER[$k])) {
                return sanitize_text_field(explode(',', $_SERVER[$k])[0]);
            }
        }
        return 'unknown';
    }
    
    private function get_device_type() {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/mobile|android|iphone/i', $ua)) {
            return preg_match('/ipad|tablet/i', $ua) ? 'tablet' : 'mobile';
        }
        return 'desktop';
    }
}

new BRE_Intelligence();
