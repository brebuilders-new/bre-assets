<?php if (!defined('ABSPATH')) exit; ?>
<div id="bre-chat">
<div id="bre-btn" onclick="breChat.toggle()">
<div class="pulse-ring"></div>
<div class="pulse-ring d2"></div>
<div class="btn-core">
<img src="https://brebuilders.com/wp-content/uploads/steve-rosenthal.jpg" alt="Steve" class="btn-avatar">
<div class="btn-status"></div>
</div>
<div class="btn-badge">1</div>
</div>

<div id="bre-win">
<div id="bre-chat-panel">
<div id="bre-hdr">
<div class="hdr-left">
<div class="hdr-avatar-wrap">
<img src="https://brebuilders.com/wp-content/uploads/steve-rosenthal.jpg" alt="Steve" class="hdr-avatar">
<div class="hdr-status"></div>
</div>
<div class="hdr-info">
<div class="hdr-name">Steve</div>
<div class="hdr-title">Owner, Blue Reef Builders • <span class="typing-status">Online</span></div>
</div>
</div>
<div class="hdr-actions">
<button class="hdr-btn" onclick="breChat.showMenu()" title="Options">
<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
</button>
<button class="hdr-btn" onclick="breChat.toggle()" title="Close">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 18L18 6M6 6l12 12"/></svg>
</button>
</div>
<div id="bre-menu" class="menu-hidden">
<button onclick="breChat.startNewChat()">🔄 Start New Conversation</button>
<button onclick="breChat.exportChat()">📄 Email This Conversation</button>
</div>
</div>

<div id="bre-msgs">
<div id="msg-loader" style="display:none"><div class="loader-spinner"></div><span>Loading history...</span></div>
</div>

<div id="bre-starters">
<div class="welcome-card">
<img src="https://brebuilders.com/wp-content/uploads/steve-rosenthal.jpg" alt="Steve" class="welcome-avatar">
<div class="welcome-content">
<div class="welcome-greeting">Hey there! I'm Steve 👋</div>
<div class="welcome-text">35 years building in Nevada & California. We take on the <em>tough projects</em> others walk away from. What are you working on?</div>
</div>
</div>
<div class="starter-grid">
<button onclick="breChat.send('Show me your kitchen remodels')" class="starter-btn">
<span class="starter-icon">🏠</span>
<span class="starter-label">Kitchen Remodels</span>
<span class="starter-arrow">→</span>
</button>
<button onclick="breChat.send('I want to build an ADU')" class="starter-btn">
<span class="starter-icon">🏡</span>
<span class="starter-label">ADU Construction</span>
<span class="starter-arrow">→</span>
</button>
<button onclick="breChat.send('Show me bathroom renovations')" class="starter-btn">
<span class="starter-icon">🚿</span>
<span class="starter-label">Bathroom Remodels</span>
<span class="starter-arrow">→</span>
</button>
<button onclick="breChat.send('I need structural repair or fire rebuild help')" class="starter-btn">
<span class="starter-icon">🔧</span>
<span class="starter-label">Structural & Fire</span>
<span class="starter-arrow">→</span>
</button>
</div>
</div>

<!-- Fluent Form Modal -->
<div id="bre-fluent-form-modal" style="display:none">
<div class="fluent-form-overlay" onclick="breChat.closeFluentForm()"></div>
<div class="fluent-form-container">
<div class="fluent-form-header">
<h3 id="fluent-form-title">Request Information</h3>
<button class="fluent-form-close" onclick="breChat.closeFluentForm()">×</button>
</div>
<div class="fluent-form-body" id="fluent-form-body">
<div class="fluent-form-loading">Loading form...</div>
</div>
</div>
</div>

<div id="bre-form-modal" style="display:none">
<div class="form-modal-content">
<button class="form-modal-close" onclick="breChat.closeFormModal()">×</button>
<div id="form-modal-body"></div>
</div>
</div>

<div id="bre-input">
<div class="input-container">
<textarea id="msg-input" placeholder="Type a message..." rows="1"></textarea>
<button id="send-btn" onclick="breChat.sendMessage()">
<svg viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
</button>
</div>
<div class="input-footer">
<span class="secure-badge"><svg viewBox="0 0 24 24" fill="currentColor" width="12" height="12"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg> Secure</span>
<span class="powered-by">Blue Reef Builders • Reno, NV</span>
</div>
</div>
</div>

<div id="bre-gallery">
<div class="gallery-header">
<button class="gallery-back" onclick="breChat.closeGallery()">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
</button>
<div class="gallery-title">
<span id="gallery-count">12</span> Projects
</div>
<button class="gallery-close" onclick="breChat.closeGallery()">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 18L18 6M6 6l12 12"/></svg>
</button>
</div>
<div id="gallery-hero">
<img id="hero-img" src="" alt="">
<div class="hero-overlay">
<div class="hero-title" id="hero-title"></div>
<div class="hero-desc" id="hero-desc"></div>
<button class="hero-cta" onclick="breChat.askAboutCurrent()">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
Ask Steve about this
</button>
</div>
<button class="hero-nav prev" onclick="breChat.galPrev()">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
</button>
<button class="hero-nav next" onclick="breChat.galNext()">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
</button>
<div class="hero-counter"><span id="hero-current">1</span> / <span id="hero-total">12</span></div>
</div>
<div id="gallery-thumbs"></div>
</div>
</div>
</div>

<style>
:root{--bg:#0a0f1a;--card:#141c2b;--card2:#1a2435;--input:#232f42;--border:#2a3a52;--text:#f0f4f8;--dim:#7a8ba3;--accent:#00d4aa;--accent2:#00b894;--glow:rgba(0,212,170,0.3);--gradient:linear-gradient(135deg,#00d4aa 0%,#00b894 100%);--radius:20px;--ease:cubic-bezier(0.4,0,0.2,1)}

*{box-sizing:border-box}
#bre-chat{position:fixed;bottom:24px;right:24px;z-index:999999;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}

/* Floating Button */
#bre-btn{width:68px;height:68px;cursor:pointer;position:relative;transition:transform .3s var(--ease)}
#bre-btn:hover{transform:scale(1.08)}
.btn-core{width:100%;height:100%;border-radius:50%;background:var(--gradient);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 32px var(--glow),0 0 0 1px rgba(0,212,170,0.2);position:relative;z-index:2;overflow:hidden}
.btn-avatar{width:100%;height:100%;object-fit:cover;border-radius:50%}
.btn-status{position:absolute;bottom:4px;right:4px;width:16px;height:16px;background:#22c55e;border-radius:50%;border:3px solid var(--bg)}
.pulse-ring{position:absolute;inset:-6px;border-radius:50%;border:2px solid var(--accent);opacity:0;animation:pulse 2.5s ease-out infinite}
.d2{animation-delay:1.25s}
@keyframes pulse{0%{transform:scale(.9);opacity:.7}100%{transform:scale(1.5);opacity:0}}
.btn-badge{position:absolute;top:-2px;right:-2px;min-width:22px;height:22px;padding:0 6px;border-radius:11px;background:#ef4444;color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;border:2px solid var(--bg);z-index:3;animation:badgePop .3s var(--ease)}
@keyframes badgePop{0%{transform:scale(0)}50%{transform:scale(1.2)}100%{transform:scale(1)}}
#bre-btn.open .pulse-ring{display:none}

/* Window */
#bre-win{display:none;position:absolute;bottom:84px;right:0;width:420px;height:680px;background:var(--bg);border-radius:var(--radius);box-shadow:0 25px 80px rgba(0,0,0,.6),0 0 0 1px var(--border),0 0 60px -10px var(--glow);overflow:hidden;animation:windowOpen .4s var(--ease);overscroll-behavior:contain}
@keyframes windowOpen{0%{opacity:0;transform:translateY(20px) scale(.95)}100%{opacity:1;transform:translateY(0) scale(1)}}
#bre-win.with-gallery{width:900px}

/* Chat Panel */
#bre-chat-panel{width:420px;height:100%;display:flex;flex-direction:column;position:absolute;left:0;top:0;background:var(--bg);z-index:2;transition:width .4s var(--ease)}
#bre-win.with-gallery #bre-chat-panel{width:380px;border-right:1px solid var(--border)}

/* Header */
#bre-hdr{padding:16px 20px;background:linear-gradient(180deg,var(--card) 0%,transparent 100%);display:flex;align-items:center;justify-content:space-between;position:relative;border-bottom:1px solid var(--border)}
.hdr-left{display:flex;align-items:center;gap:12px}
.hdr-avatar-wrap{position:relative}
.hdr-avatar{width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--accent)}
.hdr-status{position:absolute;bottom:2px;right:2px;width:12px;height:12px;background:#22c55e;border-radius:50%;border:2px solid var(--bg)}
.hdr-name{font-size:17px;font-weight:700;color:var(--text)}
.hdr-title{font-size:12px;color:var(--dim)}
.typing-status{color:var(--accent)}
.hdr-actions{display:flex;gap:8px}
.hdr-btn{width:38px;height:38px;border-radius:12px;background:var(--input);border:1px solid var(--border);color:var(--dim);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s}
.hdr-btn:hover{background:var(--card2);color:var(--text);border-color:var(--accent)}
.hdr-btn svg{width:18px;height:18px}

/* Menu */
#bre-menu{position:absolute;top:70px;right:20px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:8px;box-shadow:0 10px 40px rgba(0,0,0,.4);z-index:10;animation:menuIn .2s var(--ease)}
#bre-menu.menu-hidden{display:none}
@keyframes menuIn{0%{opacity:0;transform:translateY(-10px)}100%{opacity:1;transform:translateY(0)}}
#bre-menu button{display:flex;align-items:center;gap:10px;width:100%;padding:12px 16px;background:none;border:none;color:var(--text);font-size:14px;cursor:pointer;border-radius:8px;transition:.2s}
#bre-menu button:hover{background:var(--input)}

/* Messages */
#bre-msgs{flex:1;overflow-y:scroll !important;overflow-x:hidden;padding:20px;display:flex;flex-direction:column;gap:16px;overscroll-behavior:none;-webkit-overflow-scrolling:touch;position:relative}
#bre-msgs::-webkit-scrollbar{width:5px}
#bre-msgs::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}

.msg{display:flex;gap:10px;animation:msgIn .4s var(--ease)}
.msg.user{flex-direction:row-reverse}
@keyframes msgIn{0%{opacity:0;transform:translateY(15px)}100%{opacity:1;transform:translateY(0)}}
.msg-avatar{width:36px;height:36px;border-radius:50%;object-fit:cover;flex-shrink:0}
.msg-content{max-width:80%}
.msg-bubble{padding:14px 18px;border-radius:20px;font-size:14px;line-height:1.6;word-wrap:break-word}
.msg.assistant .msg-bubble{background:var(--card);color:var(--text);border:1px solid var(--border);border-bottom-left-radius:6px}
.msg.user .msg-bubble{background:var(--gradient);color:#fff;border-bottom-right-radius:6px}
.msg-time{font-size:11px;color:var(--dim);margin-top:6px;padding:0 4px}
.msg.user .msg-time{text-align:right}

/* Message Images */
.msg-images{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
.msg-images img{width:80px;height:80px;border-radius:12px;object-fit:cover;cursor:pointer;border:2px solid transparent;transition:.2s}
.msg-images img:hover{border-color:var(--accent);transform:scale(1.05)}
.msg-more{width:80px;height:80px;border-radius:12px;background:var(--input);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:2px solid var(--border);transition:.2s}
.msg-more:hover{border-color:var(--accent);background:var(--card2)}
.msg-more span{font-size:18px;font-weight:700;color:var(--accent)}
.msg-more small{font-size:10px;color:var(--dim)}

/* Typing Indicator */
.typing{display:flex;gap:10px;animation:msgIn .3s var(--ease)}
.typing-bubble{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:16px 20px;display:flex;align-items:center;gap:12px}
.typing-dots{display:flex;gap:5px}
.typing-dot{width:8px;height:8px;border-radius:50%;background:var(--accent);animation:typingDot 1.4s ease-in-out infinite}
.typing-dot:nth-child(2){animation-delay:.2s}
.typing-dot:nth-child(3){animation-delay:.4s}
@keyframes typingDot{0%,60%,100%{transform:translateY(0);opacity:.4}30%{transform:translateY(-8px);opacity:1}}

/* Loader */
#msg-loader{display:flex;align-items:center;justify-content:center;gap:12px;padding:20px;color:var(--dim);font-size:13px}
.loader-spinner{width:20px;height:20px;border:2px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* Starters */
#bre-starters{padding:20px;display:flex;flex-direction:column;gap:16px}
.welcome-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;display:flex;gap:16px}
.welcome-avatar{width:56px;height:56px;border-radius:50%;object-fit:cover;border:2px solid var(--accent);flex-shrink:0}
.welcome-greeting{font-size:18px;font-weight:700;color:var(--text);margin-bottom:8px}
.welcome-text{font-size:14px;color:var(--dim);line-height:1.6}
.welcome-text em{color:var(--accent);font-style:normal;font-weight:600}
.starter-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.starter-btn{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;display:flex;align-items:center;gap:12px;cursor:pointer;transition:.3s var(--ease);text-align:left}
.starter-btn:hover{border-color:var(--accent);background:rgba(0,212,170,.08);transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.2)}
.starter-icon{font-size:24px}
.starter-label{flex:1;font-size:13px;font-weight:600;color:var(--text)}
.starter-arrow{color:var(--accent);font-size:16px;opacity:0;transform:translateX(-5px);transition:.3s}
.starter-btn:hover .starter-arrow{opacity:1;transform:translateX(0)}

/* Form Modal */
#bre-form-modal{position:fixed;inset:0;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;z-index:1000000;padding:20px}
.form-modal-content{background:var(--bg);border-radius:20px;width:100%;max-width:600px;max-height:90vh;overflow-y:auto;position:relative;border:1px solid var(--border)}
.form-modal-close{position:absolute;top:15px;right:15px;width:36px;height:36px;border-radius:50%;background:var(--input);border:1px solid var(--border);color:var(--text);font-size:24px;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:10}
.form-modal-close:hover{background:var(--card2);color:var(--accent)}
#form-modal-body{padding:30px}
#form-modal-body iframe{width:100%;min-height:500px;border:none}
.form-cta-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-top:16px}
.form-cta-title{font-size:16px;font-weight:700;color:var(--text);margin-bottom:8px;display:flex;align-items:center;gap:8px}
.form-cta-desc{font-size:13px;color:var(--dim);margin-bottom:12px;line-height:1.5}
.form-cta-btn{background:var(--gradient);border:none;color:#fff;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;width:100%;transition:.2s}
.form-cta-btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px var(--glow)}

/* Fluent Form Modal */
#bre-fluent-form-modal{position:fixed;inset:0;z-index:1000001;display:flex;align-items:center;justify-content:center;padding:20px}
.fluent-form-overlay{position:absolute;inset:0;background:rgba(0,0,0,.85);backdrop-filter:blur(4px)}
.fluent-form-container{position:relative;background:#fff;border-radius:20px;width:100%;max-width:700px;max-height:90vh;overflow:hidden;box-shadow:0 25px 80px rgba(0,0,0,.5);animation:formSlideIn .3s ease}
@keyframes formSlideIn{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
.fluent-form-header{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid #e5e7eb;background:#f9fafb}
.fluent-form-header h3{margin:0;font-size:20px;font-weight:700;color:#1f2937}
.fluent-form-close{width:36px;height:36px;border-radius:50%;background:#fff;border:1px solid #e5e7eb;color:#6b7280;font-size:24px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s}
.fluent-form-close:hover{background:#fee2e2;border-color:#fca5a5;color:#dc2626}
.fluent-form-body{padding:24px;max-height:calc(90vh - 80px);overflow-y:auto;background:#fff}
.fluent-form-loading{text-align:center;padding:60px 20px;color:#6b7280}

/* Style Fluent Form inside modal */
.fluent-form-body .fluentform{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
.fluent-form-body .ff-el-input--label label{font-weight:600;color:#374151;margin-bottom:6px}
.fluent-form-body .ff-el-form-control{border-radius:10px;border:1px solid #d1d5db;padding:12px 14px;font-size:15px;transition:.2s}
.fluent-form-body .ff-el-form-control:focus{border-color:#00d4aa;box-shadow:0 0 0 3px rgba(0,212,170,.15)}
.fluent-form-body .ff-btn-submit{background:linear-gradient(135deg,#00d4aa 0%,#00b894 100%);border:none;border-radius:12px;padding:14px 28px;font-size:16px;font-weight:700;cursor:pointer;transition:.2s}
.fluent-form-body .ff-btn-submit:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,212,170,.4)}

/* Input Area */
#bre-input{padding:16px 20px;background:var(--card);border-top:1px solid var(--border)}
.input-container{display:flex;gap:12px;align-items:flex-end;background:var(--input);border:1px solid var(--border);border-radius:16px;padding:8px 8px 8px 16px;transition:.2s}
.input-container:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px rgba(0,212,170,.1)}
#msg-input{flex:1;background:none;border:none;color:var(--text);font-size:15px;resize:none;outline:none;max-height:120px;line-height:1.5}
#msg-input::placeholder{color:var(--dim)}
#send-btn{width:44px;height:44px;border-radius:12px;background:var(--gradient);border:none;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s;flex-shrink:0}
#send-btn:hover{transform:scale(1.05);box-shadow:0 4px 20px var(--glow)}
#send-btn:disabled{opacity:.4;cursor:not-allowed;transform:none}
#send-btn svg{width:20px;height:20px}
.input-footer{display:flex;justify-content:space-between;margin-top:10px;font-size:11px;color:var(--dim)}
.secure-badge{display:flex;align-items:center;gap:4px}
.secure-badge svg{fill:var(--accent)}

/* Gallery */
#bre-gallery{display:none;width:520px;height:100%;position:absolute;right:0;top:0;background:var(--bg);flex-direction:column}
#bre-win.with-gallery #bre-gallery{display:flex;animation:galleryIn .4s var(--ease)}
@keyframes galleryIn{0%{opacity:0;transform:translateX(30px)}100%{opacity:1;transform:translateX(0)}}

.gallery-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border)}
.gallery-back,.gallery-close{width:40px;height:40px;border-radius:12px;background:var(--input);border:1px solid var(--border);color:var(--dim);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s}
.gallery-back:hover,.gallery-close:hover{background:var(--card2);color:var(--text)}
.gallery-back svg,.gallery-close svg{width:20px;height:20px}
.gallery-title{font-size:18px;font-weight:700;color:var(--text)}
.gallery-title span{color:var(--accent)}

/* Hero Image */
#gallery-hero{flex:1;position:relative;overflow:hidden;background:#000}
#hero-img{width:100%;height:100%;object-fit:cover;animation:heroZoom 20s ease-in-out infinite alternate}
@keyframes heroZoom{0%{transform:scale(1)}100%{transform:scale(1.1)}}
.hero-overlay{position:absolute;bottom:0;left:0;right:0;padding:30px;background:linear-gradient(0deg,rgba(0,0,0,.9) 0%,transparent 100%)}
.hero-title{font-size:18px;font-weight:700;color:#fff;margin-bottom:8px}
.hero-desc{font-size:13px;color:rgba(255,255,255,.7);margin-bottom:16px;line-height:1.5}
.hero-cta{background:var(--gradient);border:none;color:#fff;font-size:14px;font-weight:600;padding:12px 20px;border-radius:10px;cursor:pointer;display:inline-flex;align-items:center;gap:8px;transition:.2s}
.hero-cta:hover{transform:translateY(-2px);box-shadow:0 8px 24px var(--glow)}
.hero-nav{position:absolute;top:50%;transform:translateY(-50%);width:48px;height:48px;border-radius:50%;background:rgba(0,0,0,.6);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s;opacity:0}
#gallery-hero:hover .hero-nav{opacity:1}
.hero-nav:hover{background:var(--accent);border-color:var(--accent)}
.hero-nav.prev{left:16px}
.hero-nav.next{right:16px}
.hero-nav svg{width:24px;height:24px}
.hero-counter{position:absolute;top:16px;right:16px;background:rgba(0,0,0,.6);backdrop-filter:blur(10px);padding:8px 14px;border-radius:20px;font-size:13px;color:#fff;font-weight:600}

/* Thumbnails */
#gallery-thumbs{display:flex;gap:8px;padding:12px;overflow-x:auto;background:var(--card);border-top:1px solid var(--border)}
#gallery-thumbs::-webkit-scrollbar{height:4px}
#gallery-thumbs::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px}
.gallery-thumb{width:72px;height:54px;border-radius:8px;object-fit:cover;cursor:pointer;border:2px solid transparent;transition:.2s;flex-shrink:0;opacity:.6}
.gallery-thumb:hover{opacity:1}
.gallery-thumb.active{border-color:var(--accent);opacity:1}

/* Mobile Responsive */
@media(max-width:1024px){
#bre-win{width:100%;height:100%;position:fixed;inset:0;border-radius:0;bottom:0;right:0}
#bre-win.with-gallery{width:100%}
#bre-chat-panel{width:100%}
#bre-win.with-gallery #bre-chat-panel{display:none}
#bre-gallery{width:100%;position:fixed;inset:0}
.gallery-back{display:flex}
}
@media(max-width:480px){
#bre-chat{bottom:16px;right:16px}
#bre-btn{width:60px;height:60px}
.starter-grid{grid-template-columns:1fr}
#msg-input{font-size:16px}
}
</style>

<script>
const breChat = {
    isOpen: false,
    threadId: null,
    convId: null,
    imgs: [],
    galIdx: 0,
    msgCount: 0,
    detectedProjectType: null,
    conversationHistory: [],
    steveImg: 'https://brebuilders.com/wp-content/uploads/steve-rosenthal.jpg',
    
    init() {
        // AGGRESSIVE scroll fix - prevent ANY scroll from leaking to page
        const win = document.getElementById('bre-win');
        win.addEventListener('wheel', function(e) {
            e.stopPropagation();
        }, {passive: false});
        
        win.addEventListener('touchmove', function(e) {
            e.stopPropagation();
        }, {passive: false});
        
        // Handle scroll within messages
        const msgs = document.getElementById('bre-msgs');
        msgs.addEventListener('wheel', function(e) {
            const atTop = this.scrollTop <= 0;
            const atBottom = this.scrollTop + this.clientHeight >= this.scrollHeight - 1;
            
            if (atTop && e.deltaY < 0) {
                e.preventDefault();
            } else if (atBottom && e.deltaY > 0) {
                e.preventDefault();
            }
            e.stopPropagation();
        }, {passive: false});
        
        // Auto-resize textarea
        const input = document.getElementById('msg-input');
        input.addEventListener('input', () => {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 120) + 'px';
        });
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                if (document.getElementById('bre-menu').classList.contains('menu-hidden') === false) {
                    this.hideMenu();
                } else if (document.getElementById('bre-win').classList.contains('with-gallery')) {
                    this.closeGallery();
                } else if (this.isOpen) {
                    this.toggle();
                }
            }
        });
        
        // Touch swipe for gallery
        let touchStartX = 0;
        document.getElementById('gallery-hero').addEventListener('touchstart', e => {
            touchStartX = e.touches[0].clientX;
        });
        document.getElementById('gallery-hero').addEventListener('touchend', e => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) {
                diff > 0 ? this.galNext() : this.galPrev();
            }
        });
        
        // Click outside menu to close
        document.addEventListener('click', e => {
            if (!e.target.closest('#bre-menu') && !e.target.closest('.hdr-btn')) {
                this.hideMenu();
            }
        });
    },
    
    toggle() {
        this.isOpen = !this.isOpen;
        const win = document.getElementById('bre-win');
        const btn = document.getElementById('bre-btn');
        
        if (this.isOpen) {
            win.style.display = 'block';
            btn.classList.add('open');
            document.body.style.overflow = 'hidden';
            document.querySelector('.btn-badge').style.display = 'none';
            this.loadExistingChat();
        } else {
            win.style.display = 'none';
            btn.classList.remove('open');
            document.body.style.overflow = '';
            this.closeGallery();
            this.hideMenu();
        }
    },
    
    async loadExistingChat() {
        const stored = localStorage.getItem('bre_chat');
        if (stored) {
            try {
                const s = JSON.parse(stored);
                if (s.threadId && s.convId) {
                    this.threadId = s.threadId;
                    this.convId = s.convId;
                    await this.loadHistory();
                    return;
                }
            } catch(e) {}
        }
    },
    
    async loadHistory() {
        const loader = document.getElementById('msg-loader');
        const starters = document.getElementById('bre-starters');
        
        loader.style.display = 'flex';
        
        try {
            const fd = new FormData();
            fd.append('action', 'bre_chat_get_history');
            fd.append('nonce', bre_chat_ajax.nonce);
            fd.append('conversation_id', this.convId);
            
            const r = await fetch(bre_chat_ajax.ajax_url, {method: 'POST', body: fd});
            const d = await r.json();
            
            loader.style.display = 'none';
            
            if (d.success && d.data.messages && d.data.messages.length > 0) {
                starters.style.display = 'none';
                d.data.messages.forEach(m => {
                    this.addMsg(m.role, m.content, null, false);
                });
                this.msgCount = d.data.messages.length;
                document.getElementById('bre-msgs').scrollTop = document.getElementById('bre-msgs').scrollHeight;
            }
        } catch(e) {
            loader.style.display = 'none';
            console.error('Failed to load history:', e);
        }
    },
    
    send(m) {
        document.getElementById('msg-input').value = m;
        this.sendMessage();
    },
    
    async sendMessage() {
        const input = document.getElementById('msg-input');
        const msg = input.value.trim();
        if (!msg) return;
        
        // Reset stored images for new message
        this.imgs = [];
        
        // Track conversation and detect project type
        this.conversationHistory.push(msg);
        const detected = this.detectProjectType(this.conversationHistory.join(' '));
        if (detected !== 'general') {
            this.detectedProjectType = detected;
        }
        
        document.getElementById('send-btn').disabled = true;
        this.addMsg('user', msg);
        input.value = '';
        input.style.height = 'auto';
        
        document.getElementById('bre-starters').style.display = 'none';
        this.showTyping();
        this.msgCount++;
        
        try {
            if (!this.threadId) await this.createThread();
            const r = await this.callAssistant(msg);
            this.hideTyping();
            this.processResponse(r);
            
            // Form opening is now handled by the AI Assistant via openFluentForm()
            // No automatic popup - better UX
        } catch(e) {
            console.error('Chat error:', e);
            this.hideTyping();
            this.addMsg('assistant', "Having trouble connecting right now. Give me a call at (775) 391-4517 or email steve@brebuilders.com");
        }
        
        document.getElementById('send-btn').disabled = false;
    },
    
    async createThread() {
        const stored = localStorage.getItem('bre_chat');
        if (stored) {
            try {
                const s = JSON.parse(stored);
                if (s.threadId && s.convId) {
                    this.threadId = s.threadId;
                    this.convId = s.convId;
                    return;
                }
            } catch(e) {}
        }
        
        const fd = new FormData();
        fd.append('action', 'bre_chat_create_thread');
        fd.append('nonce', bre_chat_ajax.nonce);
        fd.append('agent_name', 'Steve');
        fd.append('page_url', window.location.href);
        
        const r = await fetch(bre_chat_ajax.ajax_url, {method: 'POST', body: fd});
        const d = await r.json();
        
        if (d.success) {
            this.threadId = d.data.thread_id;
            this.convId = d.data.conversation_id;
            localStorage.setItem('bre_chat', JSON.stringify({
                threadId: this.threadId,
                convId: this.convId,
                created: Date.now()
            }));
        } else {
            throw new Error('Thread failed');
        }
    },
    
    async callAssistant(msg) {
        const fd = new FormData();
        fd.append('action', 'bre_chat_send_message');
        fd.append('nonce', bre_chat_ajax.nonce);
        fd.append('thread_id', this.threadId);
        fd.append('conversation_id', this.convId);
        fd.append('message', msg);
        fd.append('page_url', window.location.href);
        
        const r = await fetch(bre_chat_ajax.ajax_url, {method: 'POST', body: fd});
        const d = await r.json();
        
        if (!d.success) throw new Error('Send failed');
        return await this.pollResponse(d.data.run_id);
    },
    
    async pollResponse(runId, attempts = 0) {
        if (attempts > 30) throw new Error('Timeout');
        
        const fd = new FormData();
        fd.append('action', 'bre_chat_get_response');
        fd.append('nonce', bre_chat_ajax.nonce);
        fd.append('thread_id', this.threadId);
        fd.append('run_id', runId);
        fd.append('conversation_id', this.convId);
        fd.append('page_url', window.location.href);
        
        const r = await fetch(bre_chat_ajax.ajax_url, {method: 'POST', body: fd});
        const d = await r.json();
        
        if (d.success) {
            if (d.data.status === 'completed') return d.data;
            if (d.data.images) {
                this.imgs = this.dedupeImages(d.data.images.images || []);
            }
            // OpenAI statuses: queued, in_progress, requires_action, completed, failed, cancelled, expired
            // 'processing' is what we return after handling requires_action
            if (['queued', 'in_progress', 'requires_action', 'running', 'processing'].includes(d.data.status)) {
                await new Promise(r => setTimeout(r, 1200));
                return this.pollResponse(runId, attempts + 1);
            }
        }
        console.error('Poll failed:', d);
        throw new Error('Failed: ' + (d.data?.status || d.data || 'unknown'));
    },
    
    dedupeImages(imgs) {
        const seen = new Set();
        return imgs.filter(img => {
            if (seen.has(img.image_url)) return false;
            seen.add(img.image_url);
            return true;
        });
    },
    
    processResponse(data) {
        if (data.message) {
            let message = data.message;
            
            // Check for form trigger [OPEN_FORM:service_type]
            const formMatch = message.match(/\[OPEN_FORM:(\w+)\]/i);
            if (formMatch) {
                const serviceType = formMatch[1].toLowerCase();
                // Remove the tag from displayed message
                message = message.replace(/\[OPEN_FORM:\w+\]/gi, '').trim();
                
                // Open form after a short delay (let message render first)
                setTimeout(() => {
                    this.openFluentForm(serviceType);
                }, 1500);
            }
            
            // Use images from response, or fall back to previously stored images
            let images = data.images ? this.dedupeImages(data.images.images || []) : null;
            if (!images && this.imgs && this.imgs.length > 0) {
                images = this.imgs;
            }
            
            this.addMsg('assistant', message, images);
            
            if (images && images.length > 0) {
                this.imgs = images;
                setTimeout(() => this.openGallery(), 500);
            }
        }
        this.msgCount++;
    },
    
    addMsg(role, content, images, animate = true) {
        const container = document.getElementById('bre-msgs');
        const div = document.createElement('div');
        div.className = 'msg ' + role;
        if (!animate) div.style.animation = 'none';
        
        let html = '';
        if (role === 'assistant') {
            html += `<img class="msg-avatar" src="${this.steveImg}" alt="Steve">`;
        }
        
        html += `<div class="msg-content"><div class="msg-bubble">${this.formatText(content)}</div>`;
        
        if (images && images.length > 0) {
            html += '<div class="msg-images">';
            const show = Math.min(3, images.length);
            for (let i = 0; i < show; i++) {
                const thumb = images[i].thumbnail_url || images[i].image_url;
                html += `<img src="${thumb}" onclick="breChat.openGalleryAt(${i})">`;
            }
            if (images.length > 3) {
                html += `<div class="msg-more" onclick="breChat.openGallery()"><span>+${images.length - 3}</span><small>more</small></div>`;
            }
            html += '</div>';
        }
        
        html += `<div class="msg-time">${this.getTime()}</div></div>`;
        
        div.innerHTML = html;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    },
    
    formatText(t) {
        t = t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        t = t.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        t = t.replace(/\n/g, '<br>');
        t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" style="color:var(--accent)">$1</a>');
        return t;
    },
    
    getTime() {
        return new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    },
    
    showTyping() {
        const container = document.getElementById('bre-msgs');
        const div = document.createElement('div');
        div.id = 'typing-indicator';
        div.className = 'typing';
        div.innerHTML = `
            <img class="msg-avatar" src="${this.steveImg}" alt="Steve">
            <div class="typing-bubble">
                <div class="typing-dots">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            </div>
        `;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
        document.querySelector('.typing-status').textContent = 'Typing...';
    },
    
    hideTyping() {
        const t = document.getElementById('typing-indicator');
        if (t) t.remove();
        document.querySelector('.typing-status').textContent = 'Online';
    },
    
    // Gallery
    openGallery() {
        if (this.imgs.length === 0) return;
        this.galIdx = 0;
        this.renderGallery();
        document.getElementById('bre-win').classList.add('with-gallery');
    },
    
    openGalleryAt(idx) {
        this.galIdx = idx;
        this.renderGallery();
        document.getElementById('bre-win').classList.add('with-gallery');
    },
    
    closeGallery() {
        document.getElementById('bre-win').classList.remove('with-gallery');
    },
    
    renderGallery() {
        const img = this.imgs[this.galIdx];
        document.getElementById('hero-img').src = img.image_url;
        document.getElementById('hero-title').textContent = img.project_title || 'Project';
        document.getElementById('hero-desc').textContent = img.description || img.alt_text || '';
        document.getElementById('hero-current').textContent = this.galIdx + 1;
        document.getElementById('hero-total').textContent = this.imgs.length;
        document.getElementById('gallery-count').textContent = this.imgs.length;
        
        // Render thumbnails
        const thumbs = document.getElementById('gallery-thumbs');
        thumbs.innerHTML = '';
        this.imgs.forEach((im, i) => {
            const thumb = document.createElement('img');
            thumb.src = im.thumbnail_url || im.image_url;
            thumb.className = 'gallery-thumb' + (i === this.galIdx ? ' active' : '');
            thumb.onclick = () => {
                this.galIdx = i;
                this.renderGallery();
            };
            thumbs.appendChild(thumb);
        });
        
        // Scroll active thumb into view
        const activeThumb = thumbs.querySelector('.active');
        if (activeThumb) activeThumb.scrollIntoView({behavior: 'smooth', inline: 'center'});
    },
    
    galPrev() {
        this.galIdx = (this.galIdx - 1 + this.imgs.length) % this.imgs.length;
        this.renderGallery();
    },
    
    galNext() {
        this.galIdx = (this.galIdx + 1) % this.imgs.length;
        this.renderGallery();
    },
    
    askAboutCurrent() {
        const img = this.imgs[this.galIdx];
        this.closeGallery();
        document.getElementById('msg-input').value = `Tell me more about this ${img.project_title || 'project'}`;
        this.sendMessage();
    },
    
    // Menu
    showMenu() {
        document.getElementById('bre-menu').classList.remove('menu-hidden');
    },
    
    hideMenu() {
        document.getElementById('bre-menu').classList.add('menu-hidden');
    },
    
    startNewChat() {
        if (confirm('Start a fresh conversation? Your previous chat will still be saved.')) {
            localStorage.removeItem('bre_chat');
            this.threadId = null;
            this.convId = null;
            this.msgCount = 0;
            document.getElementById('bre-msgs').innerHTML = '<div id="msg-loader" style="display:none"><div class="loader-spinner"></div><span>Loading history...</span></div>';
            document.getElementById('bre-starters').style.display = 'flex';
            this.hideMenu();
        }
    },
    
    exportChat() {
        alert('This will email the conversation to you. Feature coming soon!');
        this.hideMenu();
    },
    
    // Detect project type from conversation
    detectProjectType(text) {
        const lower = text.toLowerCase();
        
        if (lower.match(/foundation|structural|crack|settling|framing|beam|support|sagging/)) {
            return 'structural';
        }
        if (lower.match(/water|moisture|leak|flood|mold|intrusion|damp/)) {
            return 'water';
        }
        if (lower.match(/new home|custom home|build new|new construction|ground up/)) {
            return 'new_home';
        }
        if (lower.match(/kitchen|cabinet|countertop/)) {
            return 'kitchen';
        }
        if (lower.match(/bathroom|bath|shower|vanity/)) {
            return 'bathroom';
        }
        if (lower.match(/adu|guest house|in-law|accessory/)) {
            return 'adu';
        }
        if (lower.match(/deck|balcony|patio|railing/)) {
            return 'deck';
        }
        if (lower.match(/commercial|office|retail|tenant/)) {
            return 'commercial';
        }
        
        return 'general';
    },
    
    // Open Fluent Form modal for a service type
    async openFluentForm(serviceType) {
        const modal = document.getElementById('bre-fluent-form-modal');
        const body = document.getElementById('fluent-form-body');
        const title = document.getElementById('fluent-form-title');
        
        // Show loading
        modal.style.display = 'flex';
        body.innerHTML = '<div class="fluent-form-loading">Loading form...</div>';
        
        try {
            const fd = new FormData();
            fd.append('action', 'bre_load_service_form');
            fd.append('nonce', bre_chat_ajax.nonce);
            fd.append('service_type', serviceType || this.detectedProjectType || 'general');
            
            const r = await fetch(bre_chat_ajax.ajax_url, {method: 'POST', body: fd});
            const d = await r.json();
            
            if (d.success) {
                title.textContent = d.data.form_title || 'Request Information';
                body.innerHTML = d.data.form_html;
                
                // Re-initialize Fluent Forms scripts if needed
                if (window.fluentFormApp) {
                    window.fluentFormApp.init();
                }
            } else {
                body.innerHTML = '<div style="text-align:center;padding:40px;color:#666">Form not available. Please call us at (775) 391-4517</div>';
            }
        } catch(e) {
            console.error('Form load error:', e);
            body.innerHTML = '<div style="text-align:center;padding:40px;color:#666">Error loading form. Please call us at (775) 391-4517</div>';
        }
    },
    
    // Close Fluent Form modal
    closeFluentForm() {
        document.getElementById('bre-fluent-form-modal').style.display = 'none';
    },
    
    // Show form CTA in chat messages
    showFormCTA(serviceType) {
        const typeNames = {
            'water': 'Water Intrusion Evaluation',
            'structural': 'Structural Inspection Request',
            'foundation': 'Foundation Inspection Request',
            'new_home': 'New Home Consultation',
            'kitchen': 'Kitchen Remodel Consultation',
            'bathroom': 'Bathroom Remodel Consultation',
            'adu': 'ADU Consultation',
            'deck': 'Deck Project Consultation',
            'commercial': 'Commercial Project Inquiry',
            'general': 'Project Consultation'
        };
        
        const formName = typeNames[serviceType] || typeNames['general'];
        
        const ctaHtml = `
            <div class="form-cta-card">
                <div class="form-cta-title">📋 ${formName}</div>
                <div class="form-cta-desc">Fill out this quick form so we can prepare for your consultation.</div>
                <button class="form-cta-btn" onclick="breChat.openFluentForm('${serviceType}')">Open Form →</button>
            </div>
        `;
        
        return ctaHtml;
    },
    
    // Legacy method for backwards compatibility
    closeFormModal() {
        document.getElementById('bre-form-modal').style.display = 'none';
    }
};

document.addEventListener('DOMContentLoaded', () => breChat.init());
</script>
