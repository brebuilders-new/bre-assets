// BRE Intelligence Admin JS
jQuery(function($) {
    'use strict';
    // Most functionality is in view-specific inline scripts
});
