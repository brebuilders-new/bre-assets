<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap bre-admin">
    <h1>Portfolio Images</h1>
    
    <div class="bre-stats-row">
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $total; ?></div>
            <div class="stat-label">Total Images</div>
        </div>
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $analyzed; ?></div>
            <div class="stat-label">AI Analyzed</div>
        </div>
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $total - $analyzed; ?></div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
    
    <!-- Actions -->
    <div class="bre-card">
        <h2>🔄 Pipeline</h2>
        
        <div class="bre-pipeline-actions">
            <div class="pipeline-step">
                <h3>Step 1: Index Images</h3>
                <p>Scan all portfolio posts and index their images</p>
                <button type="button" id="btn-index" class="button button-primary">Index All Portfolio</button>
            </div>
            
            <div class="pipeline-step">
                <h3>Step 2: AI Analysis</h3>
                <p>Analyze images with GPT-4o (~$0.005/image)</p>
                <?php if ($total - $analyzed > 0): ?>
                <button type="button" id="btn-analyze" class="button button-primary">Analyze <?php echo $total - $analyzed; ?> Images</button>
                <?php else: ?>
                <span style="color:green;">✓ All analyzed</span>
                <button type="button" id="btn-reset-analysis" class="button" style="margin-left:10px;">🔄 Re-analyze All</button>
                <?php endif; ?>
            </div>
            
            <?php if ($analyzed > 0 && $total - $analyzed > 0): ?>
            <div class="pipeline-step">
                <h3>Reset</h3>
                <p>Clear analysis to re-run with updated prompt</p>
                <button type="button" id="btn-reset-analysis" class="button">🔄 Reset All Analysis</button>
            </div>
            <?php endif; ?>
        </div>
        
        <div id="pipeline-progress" style="margin-top:20px;display:none;">
            <div class="progress-bar"><div class="progress-fill" id="pipeline-bar"></div></div>
            <p id="pipeline-status"></p>
            <div id="pipeline-preview" style="margin-top:10px;display:none;">
                <img id="preview-thumb" src="" style="width:100px;height:70px;object-fit:cover;border-radius:4px;">
                <span id="preview-desc"></span>
            </div>
        </div>
    </div>
    
    <!-- Service Types -->
    <?php if ($by_service): ?>
    <div class="bre-card">
        <h2>🏷️ By Service Type</h2>
        <div class="bre-tags">
            <?php foreach ($by_service as $svc): ?>
            <span class="tag"><?php echo esc_html($svc->ai_service_type); ?> (<?php echo $svc->cnt; ?>)</span>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Images Grid -->
    <div class="bre-card">
        <h2>📷 Images (<?php echo count($images); ?>)</h2>
        
        <div class="bre-image-grid">
            <?php foreach ($images as $img): ?>
            <div class="bre-image-card">
                <img src="<?php echo esc_url($img->thumbnail_url); ?>" alt="">
                <div class="image-overlay">
                    <div class="image-title"><?php echo esc_html($img->project_title); ?></div>
                    <?php if ($img->ai_description): ?>
                    <div class="image-desc"><?php echo esc_html(substr($img->ai_description, 0, 60)); ?></div>
                    <?php endif; ?>
                    <div class="image-badges">
                        <?php if ($img->ai_service_type): ?>
                        <span class="badge"><?php echo esc_html($img->ai_service_type); ?></span>
                        <?php endif; ?>
                        <?php if ($img->is_featured): ?>
                        <span class="badge badge-featured">Featured</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
jQuery(function($) {
    var running = false;
    
    // Index
    $('#btn-index').on('click', function() {
        if (running) return;
        running = true;
        
        var $btn = $(this);
        var $progress = $('#pipeline-progress');
        var $bar = $('#pipeline-bar');
        var $status = $('#pipeline-status');
        
        $btn.prop('disabled', true);
        $progress.show();
        $bar.css('width', '0%');
        
        function doIndex(offset) {
            $.post(breAdmin.ajax, {
                action: 'bre_index_portfolio',
                nonce: breAdmin.nonce,
                offset: offset
            }, function(res) {
                if (!res.success) {
                    $status.text('Error: ' + res.data);
                    $btn.prop('disabled', false);
                    running = false;
                    return;
                }
                
                if (res.data.done) {
                    $bar.css('width', '100%');
                    $status.text('Complete!');
                    setTimeout(function() { location.reload(); }, 1000);
                    return;
                }
                
                var pct = Math.round((res.data.offset / res.data.total) * 100);
                $bar.css('width', pct + '%');
                $status.text('Indexed ' + res.data.indexed + ' images (post ' + res.data.offset + '/' + res.data.total + ')');
                
                setTimeout(function() { doIndex(res.data.offset); }, 100);
            });
        }
        
        doIndex(0);
    });
    
    // Analyze
    $('#btn-analyze').on('click', function() {
        if (running) return;
        running = true;
        
        var $btn = $(this);
        var $progress = $('#pipeline-progress');
        var $bar = $('#pipeline-bar');
        var $status = $('#pipeline-status');
        var $preview = $('#pipeline-preview');
        
        $btn.prop('disabled', true);
        $progress.show();
        $preview.show();
        
        function doAnalyze() {
            $.post(breAdmin.ajax, {
                action: 'bre_analyze_images',
                nonce: breAdmin.nonce
            }, function(res) {
                if (!res.success) {
                    $status.text('Error: ' + res.data);
                    $btn.prop('disabled', false);
                    running = false;
                    return;
                }
                
                if (res.data.done) {
                    $bar.css('width', '100%');
                    $status.text('Complete!');
                    $preview.hide();
                    setTimeout(function() { location.reload(); }, 1000);
                    return;
                }
                
                $('#preview-thumb').attr('src', res.data.thumbnail);
                $('#preview-desc').text(res.data.description || res.data.analyzed);
                $status.text(res.data.remaining + ' remaining');
                
                setTimeout(doAnalyze, 500);
            });
        }
        
        doAnalyze();
    });
    
    // Reset analysis
    $('#btn-reset-analysis').on('click', function() {
        if (!confirm('This will clear all AI analysis and allow re-running. Continue?')) return;
        
        $.post(breAdmin.ajax, {
            action: 'bre_reset_analysis',
            nonce: breAdmin.nonce
        }, function(res) {
            if (res.success) {
                alert('Analysis reset! ' + res.data.count + ' images ready for re-analysis.');
                location.reload();
            } else {
                alert('Error: ' + res.data);
            }
        });
    });
});
</script>
