<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap bre-admin">
    <h1>BRE Intelligence - Conversations</h1>
    
    <div class="bre-stats-row">
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $today; ?></div>
            <div class="stat-label">Today</div>
        </div>
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $leads; ?></div>
            <div class="stat-label">Leads Captured</div>
        </div>
        <div class="bre-stat-card">
            <div class="stat-number"><?php echo $total; ?></div>
            <div class="stat-label">Total Chats</div>
        </div>
    </div>
    
    <div class="bre-card">
        <h2>Recent Conversations</h2>
        
        <div class="bre-conversations-container">
            <div class="bre-conversations-list">
                <?php if (empty($conversations)): ?>
                <div class="bre-empty">No conversations yet. The chat widget will log conversations here.</div>
                <?php else: ?>
                <?php foreach ($conversations as $conv): ?>
                <div class="bre-conv-item" data-id="<?php echo $conv->id; ?>">
                    <div class="conv-header">
                        <span class="conv-status status-<?php echo $conv->status; ?>"><?php echo ucfirst($conv->status); ?></span>
                        <span class="conv-time"><?php echo human_time_diff(strtotime($conv->last_message_at)); ?> ago</span>
                    </div>
                    <div class="conv-preview">
                        <?php echo esc_html(substr($conv->first_message ?: 'No messages', 0, 80)); ?>
                    </div>
                    <div class="conv-meta">
                        <?php if ($conv->lead_name): ?>
                        <span class="conv-lead">👤 <?php echo esc_html($conv->lead_name); ?></span>
                        <?php endif; ?>
                        <span class="conv-device"><?php echo esc_html($conv->visitor_device); ?></span>
                        <span class="conv-msgs"><?php echo $conv->message_count; ?> msgs</span>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="bre-conversation-detail" id="conv-detail">
                <div class="detail-empty">Select a conversation to view details</div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(function($) {
    $('.bre-conv-item').on('click', function() {
        var id = $(this).data('id');
        var $detail = $('#conv-detail');
        
        $('.bre-conv-item').removeClass('active');
        $(this).addClass('active');
        
        $detail.html('<div class="detail-loading">Loading...</div>');
        
        $.post(breAdmin.ajax, {
            action: 'bre_admin_get_conversation',
            nonce: breAdmin.nonce,
            conversation_id: id
        }, function(res) {
            if (!res.success) {
                $detail.html('<div class="detail-error">Failed to load</div>');
                return;
            }
            
            var conv = res.data.conversation;
            var msgs = res.data.messages;
            
            var html = '<div class="detail-header">';
            html += '<h3>Conversation #' + conv.id + '</h3>';
            if (conv.lead_name) {
                html += '<div class="detail-lead">';
                html += '<strong>' + conv.lead_name + '</strong>';
                if (conv.lead_email) html += '<br><a href="mailto:' + conv.lead_email + '">' + conv.lead_email + '</a>';
                if (conv.lead_phone) html += '<br>' + conv.lead_phone;
                html += '</div>';
            }
            html += '<div class="detail-meta">';
            html += '<span>Page: ' + (conv.visitor_page || 'Unknown') + '</span>';
            html += '<span>Device: ' + conv.visitor_device + '</span>';
            html += '</div>';
            html += '</div>';
            
            html += '<div class="detail-messages">';
            msgs.forEach(function(m) {
                html += '<div class="msg msg-' + m.role + '">';
                html += '<div class="msg-role">' + (m.role === 'user' ? 'Visitor' : 'Steve') + '</div>';
                html += '<div class="msg-content">' + m.content.replace(/\n/g, '<br>') + '</div>';
                html += '</div>';
            });
            html += '</div>';
            
            $detail.html(html);
        });
    });
});
</script>
