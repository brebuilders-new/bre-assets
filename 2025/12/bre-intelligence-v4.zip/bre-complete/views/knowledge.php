<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap bre-admin">
    <h1>Knowledge Base</h1>
    
    <!-- llms.txt Management -->
    <div class="bre-card">
        <h2>📄 llms.txt Content</h2>
        <p class="description">Sync from your Rank Math generated llms.txt to populate the knowledge base.</p>
        
        <div class="bre-llms-controls">
            <div class="bre-llms-info">
                <strong>URL:</strong> <?php echo esc_url($llms_url); ?><br>
                <strong>Last Sync:</strong> <?php echo $last_sync ? date('M j, Y g:i A', strtotime($last_sync)) : 'Never'; ?>
            </div>
            <div class="bre-llms-actions">
                <button type="button" id="btn-sync-llms" class="button button-primary">🔄 Sync from URL</button>
            </div>
        </div>
        
        <div class="bre-llms-stats">
            <span class="stat">📁 Portfolio: <strong><?php echo count($parsed['portfolio']); ?></strong></span>
            <span class="stat">📝 Posts: <strong><?php echo count($parsed['posts']); ?></strong></span>
            <span class="stat">📄 Pages: <strong><?php echo count($parsed['pages']); ?></strong></span>
        </div>
        
        <div id="sync-status" style="margin:15px 0;display:none;"></div>
        
        <details style="margin-top:15px;">
            <summary style="cursor:pointer;font-weight:bold;">View/Edit Raw Content</summary>
            <textarea id="llms-content" rows="15" style="width:100%;font-family:monospace;font-size:12px;margin-top:10px;"><?php echo esc_textarea($llms_content); ?></textarea>
            <button type="button" id="btn-save-llms" class="button" style="margin-top:10px;">💾 Save Changes</button>
        </details>
    </div>
    
    <!-- Fetch Content -->
    <div class="bre-card">
        <h2>📥 Fetch Page Content</h2>
        <p class="description">Download actual content from each URL in llms.txt for the AI to reference.</p>
        
        <?php
        global $wpdb;
        $unfetched = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bre_knowledge WHERE fetched = 0");
        $fetched = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bre_knowledge WHERE fetched = 1");
        ?>
        
        <p><strong><?php echo $fetched; ?></strong> fetched, <strong><?php echo $unfetched; ?></strong> remaining</p>
        
        <?php if ($unfetched > 0): ?>
        <button type="button" id="btn-fetch-content" class="button button-primary">📥 Fetch Content</button>
        <div id="fetch-progress" style="margin-top:15px;display:none;">
            <div class="progress-bar"><div class="progress-fill" id="fetch-bar"></div></div>
            <p id="fetch-status"></p>
        </div>
        <?php else: ?>
        <p style="color:green;">✓ All content fetched</p>
        <?php endif; ?>
    </div>
    
    <!-- Knowledge Items -->
    <div class="bre-card">
        <h2>📚 Knowledge Items (<?php echo count($knowledge); ?>)</h2>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width:80px;">Type</th>
                    <th>Title</th>
                    <th style="width:100px;">Service</th>
                    <th style="width:80px;">Fetched</th>
                    <th style="width:100px;">Content</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($knowledge)): ?>
                <tr><td colspan="5">No items yet. Sync your llms.txt above.</td></tr>
                <?php else: ?>
                <?php foreach ($knowledge as $item): ?>
                <tr>
                    <td><span class="badge badge-<?php echo $item->source_type; ?>"><?php echo ucfirst($item->source_type); ?></span></td>
                    <td>
                        <strong><?php echo esc_html($item->title); ?></strong><br>
                        <small><a href="<?php echo esc_url($item->url); ?>" target="_blank"><?php echo esc_url($item->url); ?></a></small>
                    </td>
                    <td><?php echo esc_html($item->service_type ?: '—'); ?></td>
                    <td><?php echo $item->fetched ? '✓' : '—'; ?></td>
                    <td><?php echo $item->content ? strlen($item->content) . ' chars' : '—'; ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
jQuery(function($) {
    // Sync llms.txt
    $('#btn-sync-llms').on('click', function() {
        var $btn = $(this);
        var $status = $('#sync-status');
        
        $btn.prop('disabled', true).text('Syncing...');
        $status.show().html('<span style="color:#666;">Fetching llms.txt...</span>');
        
        $.post(breAdmin.ajax, {
            action: 'bre_sync_llms',
            nonce: breAdmin.nonce
        }, function(res) {
            $btn.prop('disabled', false).text('🔄 Sync from URL');
            
            if (res.success) {
                $status.html('<span style="color:green;">✓ Synced! ' + res.data.portfolio + ' portfolio, ' + res.data.posts + ' posts, ' + res.data.pages + ' pages</span>');
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                $status.html('<span style="color:red;">✗ ' + res.data + '</span>');
            }
        });
    });
    
    // Save llms content
    $('#btn-save-llms').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Saving...');
        
        $.post(breAdmin.ajax, {
            action: 'bre_save_llms_content',
            nonce: breAdmin.nonce,
            content: $('#llms-content').val()
        }, function(res) {
            $btn.prop('disabled', false).text('💾 Save Changes');
            alert(res.success ? 'Saved! ' + res.data.portfolio + ' portfolio, ' + res.data.posts + ' posts, ' + res.data.pages + ' pages' : 'Error: ' + res.data);
            if (res.success) location.reload();
        });
    });
    
    // Fetch content
    $('#btn-fetch-content').on('click', function() {
        var $btn = $(this);
        var $progress = $('#fetch-progress');
        var $bar = $('#fetch-bar');
        var $status = $('#fetch-status');
        
        $btn.prop('disabled', true);
        $progress.show();
        
        function doFetch() {
            $.post(breAdmin.ajax, {
                action: 'bre_fetch_knowledge',
                nonce: breAdmin.nonce
            }, function(res) {
                if (!res.success) {
                    $status.text('Error: ' + res.data);
                    $btn.prop('disabled', false);
                    return;
                }
                
                if (res.data.done) {
                    $bar.css('width', '100%');
                    $status.text('Complete!');
                    setTimeout(function() { location.reload(); }, 1000);
                    return;
                }
                
                $status.text('Fetched: ' + res.data.fetched + ' (' + res.data.remaining + ' remaining)');
                setTimeout(doFetch, 500);
            });
        }
        
        doFetch();
    });
});
</script>
