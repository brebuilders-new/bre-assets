<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap bre-admin">
    <h1>BRE Intelligence Settings</h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('bre_settings'); ?>
        
        <div class="bre-card">
            <h2>🤖 OpenAI Configuration</h2>
            <table class="form-table">
                <tr>
                    <th>API Key</th>
                    <td>
                        <input type="password" name="bre_openai_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
                        <p class="description">Your OpenAI API key</p>
                    </td>
                </tr>
                <tr>
                    <th>Assistant ID</th>
                    <td>
                        <input type="text" name="bre_openai_assistant_id" value="<?php echo esc_attr($assistant_id); ?>" class="regular-text" placeholder="asst_...">
                        <p class="description">Your OpenAI Assistant ID</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="bre-card">
            <h2>📄 llms.txt Configuration</h2>
            <table class="form-table">
                <tr>
                    <th>llms.txt URL</th>
                    <td>
                        <input type="url" name="bre_llms_url" value="<?php echo esc_url($llms_url); ?>" class="regular-text">
                        <p class="description">Usually: <?php echo esc_url(home_url('/llms.txt')); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="bre-card">
            <h2>📋 Fluent Form Mapping</h2>
            <p class="description">Map service types to Fluent Form IDs</p>
            <table class="form-table">
                <?php
                $services = [
                    'general' => 'General Inquiry',
                    'kitchen' => 'Kitchen Remodel',
                    'bathroom' => 'Bathroom Remodel',
                    'adu' => 'ADU Construction',
                    'structural' => 'Structural Repair',
                    'foundation' => 'Foundation Inspection',
                    'water' => 'Water Intrusion',
                    'new_home' => 'New Home Construction',
                    'deck' => 'Deck Project',
                    'commercial' => 'Commercial Project'
                ];
                foreach ($services as $key => $label): ?>
                <tr>
                    <th><?php echo $label; ?></th>
                    <td>
                        <input type="number" name="bre_form_mapping[<?php echo $key; ?>]" value="<?php echo esc_attr($form_mapping[$key] ?? ''); ?>" class="small-text" placeholder="Form ID">
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        
        <?php submit_button('Save Settings'); ?>
    </form>
</div>
